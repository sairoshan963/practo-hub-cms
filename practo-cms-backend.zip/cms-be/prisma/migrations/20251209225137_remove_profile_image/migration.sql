-- AlterTable
ALTER TABLE "User" DROP COLUMN "profile_image";
